# 📱 To-Do App by Charishma

A modern Android To-Do app built using **Jetpack Compose**, **MVVM**, **Room**, **Coroutines**, and **Firebase**.

## ✨ Features

- Jetpack Compose UI
- Room Database with MVVM
- Task reminders with Notifications
- Dark Mode support
- Firebase Firestore integration for syncing tasks

## 🛠️ Tech Stack

- Kotlin
- Jetpack Compose
- Room + Coroutines
- Firebase Firestore
- MVVM Architecture

## 🧠 Author

Developed and customized by **Charishma**, inspired by open-source projects.

## 📸 Screenshots

| Home Screen | Add Task | Reminder |
|-------------|----------|----------|
| ![Home](screenshots/home_screen.png) | ![Add](screenshots/add_task.png) | ![Reminder](screenshots/reminder.png) |

| Dark Mode | Firebase Sync |
|-----------|----------------|
| ![Dark](screenshots/dark_mode.png) | ![Firebase](screenshots/firebase_sync.png) |

## 📤 How to Use

1. Clone or download the repo.
2. Open in Android Studio.
3. Add your `google-services.json` for Firebase.
4. Build & Run.

---
